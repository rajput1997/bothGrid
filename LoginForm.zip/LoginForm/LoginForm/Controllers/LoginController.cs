﻿using LoginForm.Models;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace LoginForm.Controllers
{
    public class LoginController : Controller
    {
        private readonly LoginDbContext _auc;

        public LoginController(LoginDbContext auc)
        {
            _auc = auc;
        }
       
        public IActionResult Index()
        {

            return View();
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]

      //GetAll Employee record the table  displaye the views
        public IActionResult GetAllEmployee()
        {
            var logns = _auc.UserRegistration.ToList();
            return View(logns);
        }
   
            public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Login uc)
       {
            _auc.Add(uc);
            var MySecurity = "this%$#@ismyKey1050$@*&";
            var aa = uc.Pwd.GetHashCode();
            var NewPassword = aa + MySecurity + aa + MySecurity;

            uc.Pwd = NewPassword.ToString(); 
            _auc.SaveChanges();
            TempData["error"] = "Recored Saved...";

            ViewBag.message = "The user " + uc.Username + " is saved successfully";
            return View(uc);
        }
       
    }
}