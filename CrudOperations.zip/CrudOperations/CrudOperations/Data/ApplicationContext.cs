﻿using CrudOperations.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrudOperations.Data
{
    public class ApplicationContext : DbContext
    {

        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options)
        { }

        // The DbSet property will tell EF Core tha we have a table that needs to be created
        public DbSet<Employee>  Employees{ get; set; }
    }
}
